package interfacepackage;

import mainpackage.*;

public interface CourseUIInterface 
{
   public void ShowScreen();

}
