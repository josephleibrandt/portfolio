package mainpackage;

import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;
import java.util.Scanner;
import interfacepackage.*;


public abstract class ConsoleUI implements CourseUIInterface
{
   public ConsoleUI(){}
   abstract public void ShowScreen();
   
}


class Screen1 extends ConsoleUI
{
	public Screen1(){}
	
	public void ShowScreen()
	{
		System.out.println("Screen1: "); 
	}
}


class Screen2 extends ConsoleUI
{
	public Screen2(){}
		
	public void ShowScreen()
	{
		System.out.println("Screen2: "); 
	}

}


class Screen3 extends ConsoleUI
{
	public Screen3(){}
		
	public void ShowScreen()
	{
		System.out.println("Screen3: "); 
	}

}
