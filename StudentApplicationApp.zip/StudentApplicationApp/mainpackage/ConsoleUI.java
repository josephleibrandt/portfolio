package mainpackage;

import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;

import interfacepackage.*;
 
public abstract class ConsoleUI implements CourseUIInterface {

    public ConsoleUI() {
    }

    abstract public void ShowScreen();
    abstract public void contentBuilder();
 
   public void header() {
        System.out.println("\n");
        System.out.println("##################################################################");
        System.out.println("|         Welcome to University of California - Irvine           |");
        System.out.println("##################################################################");
        //System.out.println("\n");
    }

    public void className(String course) {
        System.out.println(course);
    }

    public void closeHeader() {
        System.out.println("############################");

    }

    public void separator() {
        System.out.println("------------------------------------------------------------------");

    }

    public void footer() {

    }

    public static void clearConsole() {
        //Clears Screen in java
        try {
            if (System.getProperty("os.name").contains("Windows")) {
                new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
            } else {
                Runtime.getRuntime().exec("clear");
            }
        } catch (IOException | InterruptedException ex) {
        }
    }

    public static String Padding(String s, int colWidth, String paddingType) {
        int lenght = s.trim().length();
        int totFreeSpace = colWidth - lenght;

        if (paddingType == "center") {
            int left = (totFreeSpace / 2) + lenght + 1;
            String s1 = String.format("%1$-" + left + "s", s);
            String s2 = String.format("%1$" + colWidth + "s", s1);
            return s2;
        } else if (paddingType == "rightcenter") {
            int left = (colWidth / 2) + 1;
            String s1 = String.format("%1$" + left + "s", s);
            String s2 = String.format("%1$-" + colWidth + "s", s1);
            return s2;
        } else if (paddingType == "leftcenter") {
            int left = (colWidth / 2) + 2;
            String s1 = String.format("%1$-" + left + "s", s);
            String s2 = String.format("%1$" + colWidth + "s", s1);
            return s2;
        } else if (paddingType == "right") {
            String s2 = String.format("%1$" + colWidth + "s", s);
            return s2;
        } else if (paddingType == "left") {
            int left = colWidth / 2;
            String s1 = String.format("%1$-" + colWidth + "s", s);
            String s2 = String.format("%1$" + left + "s", s1);
            return s2;
        } else {
            String e = "Error:!?";
            int left = (totFreeSpace / 2) + lenght + 1;
            String s1 = String.format("%1$-" + left + "s", e);
            String s2 = String.format("%1$" + colWidth + "s", s1);
            return s2;
        }

    }

}

class LogInScreen extends ConsoleUI {

    private String userName;
    private String password;

    public LogInScreen() {
    }

    public void ShowScreen() {
        ConsoleUI.clearConsole();
        super.header();
        super.separator();

        this.contentBuilder();
        //super.separator();

    }

    @Override
    public void header() {
        super.header();
    }

    @Override
    public void separator() {

    }

    @Override
    public void closeHeader() {

    }

    @Override
    public void footer() {

    }

    public void contentBuilder() {
        System.out.println("Loggin Screen - Please login below: \n");
        Scanner input = new Scanner(System.in);
        System.out.print("User Name:");
        this.userName = input.nextLine();
         
        System.out.print("Password:");
        this.password = input.nextLine();
    }

    public String getPassword() {
        return this.password;
    }

    public String getUserName() {
        return this.userName;
    }

    public void successLoggin() {
        this.header();
        System.out.println("Loggin Successful");

    }
}

class StudentProfileScreen extends ConsoleUI {

    RegistrationHandlerData registrations = new RegistrationHandlerData();
    CourseHandlerData courses = new CourseHandlerData();
    private Student student;

    public StudentProfileScreen(Student s) {
        this.student = s;
    }

    public void ShowScreen() {
        ConsoleUI.clearConsole();
        super.header();        
        super.separator();;
        this.contentBuilder();
        super.separator();

    }

    @Override
    public void header() {
 

    }

    @Override
    public void separator() {

    }

    @Override
    public void closeHeader() {

    }

    @Override
    public void footer() {
     
    }

    public void contentBuilder() {
    	
        StudentHandlerData studentData = new StudentHandlerData();
        ArrayList<ArrayList> studentRegistration = studentData.getStudentRegistration(student.GetStudentID());
        
        Scanner input = new Scanner(System.in);
        int choice = -1;
        while (true) {
        	System.out.println("---------------------------------------------------------");		
        	System.out.println("MESSAGE: Enrollment profile for student: " + student.GetLastName() +", " + student.GetFirstName());
        	System.out.println();
        	System.out.println("MESSAGE: Student is enrolled in the following classes:");
        	System.out.println("---------------------------------------------------------");

            System.out.println();
            System.out.println(" ________________________________________________");
            System.out.println("|" + ConsoleUI.Padding("Index", 6, "center")
                    + "|" + ConsoleUI.Padding("SID", 4, "center")
                    + "|" + ConsoleUI.Padding("Course ID", 10, "center")
                    + "|" + ConsoleUI.Padding("Course Name", 25, "center") + "|");
            System.out.println("|______|____|__________|_________________________|");

            int index = 1;
            for (ArrayList studentReg : studentRegistration) {
                System.out.println("|" + ConsoleUI.Padding(String.valueOf(index), 6, "center")
                        + "|" + ConsoleUI.Padding(String.valueOf(studentReg.get(0)), 4, "center")
                        + "|" + ConsoleUI.Padding(String.valueOf(studentReg.get(1)), 10, "center")
                        + "|" + ConsoleUI.Padding(String.valueOf(studentReg.get(2)), 25, "center")
                        + "|");
                index++;
            }
            System.out.println("|______|____|__________|_________________________|");

            System.out.println();
            System.out.println("MESSAGE: Please select the course you want to see detail for and press ENTER. Press 0 to return.");
            System.out.println();
            System.out.print("CONSOLE: Enter your choice? :");
            
            /*Input Control Logic*/
            String inputString = input.nextLine();
            boolean isChoiceValid = false;
  		    isChoiceValid  = StudentClassRegistration.inputValidation(inputString,0,index-1); //Allow only integer values equal of less that 5 screens
  		  
	  		  while (!isChoiceValid){
	  			  System.out.print ("Your input is not valid. Please select one of the options from the list? ");
	  			  inputString = input.nextLine();
	    		    isChoiceValid  = StudentClassRegistration.inputValidation(inputString,0,index-1); //Allow only integer values equal of less that 5 screens

	  			  
	  		  }
	  		 
	  		choice = (int)Double.parseDouble(inputString);

            if (choice == 0) {
                break;
            }

            //System.out.println(choice);
            String courseId = String.valueOf(studentRegistration.get(choice-1).get(1));
            
             Course  course = courses.getCourse(courseId); 
            CourseDetail cDetail = new CourseDetail(course);

            System.out.println();
            cDetail.showCourseDetail();             

            System.out.println("\nMESSAGE: Please ANY KEY and ENTER to continue.");
            input.nextLine();
        }

    }

}

class AvailableCourseScreen extends ConsoleUI {

    CourseHandlerData courses = new CourseHandlerData();

    public AvailableCourseScreen() {
    }

    public void ShowScreen() {
        ConsoleUI.clearConsole();
        super.header();
        super.separator();

        this.contentBuilder();
        super.separator();

    }

    @Override
    public void header() {
        System.out.println();
        

    }

    @Override
    public void separator() {

    }

    @Override
    public void closeHeader() {

    }

    @Override
    public void footer() {

    }

    public void contentBuilder() {
 
        Scanner input = new Scanner(System.in);

        int choice;
        while (true) {
            this.header();
           	System.out.println("--------------------------");
            System.out.println("Courses offered this term:");
            System.out.println("--------------------------");
            System.out.println();
            
            System.out.println(" ___________________________________________________________________________");
            System.out.println("|" + ConsoleUI.Padding("Index", 6, "center") + "|" + ConsoleUI.Padding("Course ID", 10, "center") + "|"
                    + ConsoleUI.Padding("Course Name", 21, "center") + "| " + ConsoleUI.Padding("Course Date", 34, "center") + "|");
            System.out.println("|______|__________|_____________________|___________________________________|");

            int index = 1;
            for (Course course : courses.getCourseList()) {

                System.out.println("|" + ConsoleUI.Padding(String.valueOf(index), 6, "center")
                        + "|" + ConsoleUI.Padding(course.GetCourseID(), 10, "center")
                        + "|" + ConsoleUI.Padding(course.GetCourseName(), 21, "center")
                        + "|" + ConsoleUI.Padding(course.GetClassDate(), 35, "center")
                        + "|");
                index++;
            }

            System.out.println("|______|__________|_____________________|___________________________________|");

            System.out.println();
            System.out.println("MESSAGE: Please select the course you want to see details for and press ENTER. Press 0 to return.");
            System.out.println();
            System.out.print("Enter your choice? :");
            
            
            /*Input Control Logic*/
            
            String inputString = input.nextLine();
            boolean isChoiceValid = false;
  		    isChoiceValid  = StudentClassRegistration.inputValidation(inputString,0,index-1); //Allow only integer values equal of less that 5 screens
  		  
	  		  while (!isChoiceValid){
	  			  System.out.print ("Your input is not valid. Please select one of the options from the list? ");
	  			  inputString = input.nextLine();
	    		    isChoiceValid  = StudentClassRegistration.inputValidation(inputString,0,index-1); //Allow only integer values equal of less that 5 screens

	  			  
	  		  }
	  		  
	  		choice = (int)Double.parseDouble(inputString);
 	  		
            if (choice == 0) {
                break;
            }

            //System.out.println(choice);
            CourseDetail cDetail = new CourseDetail(courses.getCourseList().get(choice - 1));

            System.out.println();
            cDetail.showCourseDetail();
          

            System.out.println("\nMESSAGE: Please ANY KEY and ENTER to continue.");
            input.nextLine();

        }

    }

}

class UnEnrollmentScreen extends ConsoleUI {

    RegistrationHandlerData registrations = new RegistrationHandlerData();
    CourseHandlerData courses = new CourseHandlerData();

    private Student student;

    public UnEnrollmentScreen(Student s) {

        this.student = s;

    }

    public void ShowScreen() {
        ConsoleUI.clearConsole();
        super.header();
        super.separator();
        this.header();
        this.contentBuilder();
        super.separator();

    }

    @Override
    public void header() {
         System.out.println();

    	 System.out.println("UN-ENROLLMENT SCREEN:");
    }

    @Override
    public void separator() {

    }

    @Override
    public void closeHeader() {

    }

    @Override
    public void footer() {

    }

    public void contentBuilder() {
        StudentHandlerData studentData = new StudentHandlerData();
        ArrayList<ArrayList> studentRegistration = studentData.getStudentRegistration(student.GetStudentID());

        System.out.println();
        System.out.println("------------------------------------------------------------");
        System.out.println("MESSAGE: You can only unregister from the following classes:");
        System.out.println("------------------------------------------------------------");
        
        System.out.println(" ________________________________________________");
        System.out.println("|" + ConsoleUI.Padding("Index", 6, "center")
                + "|" + ConsoleUI.Padding("SID", 4, "center")
                + "|" + ConsoleUI.Padding("Course ID", 10, "center")
                + "|" + ConsoleUI.Padding("Course Name", 25, "center") + "|");
        System.out.println("|______|____|__________|_________________________|");

        
        int index = 1;
        for (ArrayList studentReg : studentRegistration) {
            System.out.println("|" + ConsoleUI.Padding(String.valueOf(index), 6, "center")
                    + "|" + ConsoleUI.Padding(String.valueOf(studentReg.get(0)), 4, "center")
                    + "|" + ConsoleUI.Padding(String.valueOf(studentReg.get(1)), 10, "center")
                    + "|" + ConsoleUI.Padding(String.valueOf(studentReg.get(2)), 25, "center")
                    + "|");
            index++;
        }
        System.out.println("|______|____|__________|_________________________|");

        System.out.println();
        System.out.println("MESSAGE: The screen displays summary information about courses. Please see the class detail from available classes Screen for more detailed description.");
        System.out.println();
        System.out.println("MESSAGE: Please select the course you want to un-register for by selecting options 1-" + (index - 1) + " or press 0 to return.");

        Scanner input = new Scanner(System.in);
        int choice = -1;

        while (true) {
            System.out.println();
            System.out.print("What is you choice? ");
            
            /*Input Control Logic*/
            String inputString = input.nextLine();
            boolean isChoiceValid = false;
  		    isChoiceValid  = StudentClassRegistration.inputValidation(inputString,0,index-1); //Allow only integer values equal of less that 5 screens
  		  
	  		  while (!isChoiceValid){
	  			  System.out.print ("Your input is not valid. Please select one of the options from the list? ");
	  			  inputString = input.nextLine();
	    		   isChoiceValid  = StudentClassRegistration.inputValidation(inputString,0,index-1); //Allow only integer values equal of less that 5 screens
 
	  		  }
	  		 
	  		choice = (int)Double.parseDouble(inputString);
      
            if (choice == 0) {
                break;
            }
            String courseId = String.valueOf(studentRegistration.get(choice - 1).get(1));

            String studentid = student.GetStudentID();
            
            //Considering the design I must refresh the regrestration object if changes are during the registration
            registrations=null;            
            registrations = new RegistrationHandlerData();
            
             
            int messageCode = registrations.UnEnrollStudentInClass(courseId, studentid);
             System.out.println();
            System.out.println("REGISTRATION MESSAGE: " + registrations.printEnrollmentMessage(messageCode));

        }

    }

}

class EnrollmentScreen extends ConsoleUI {

    RegistrationHandlerData registrations = new RegistrationHandlerData();
    CourseHandlerData courses = new CourseHandlerData();

    private Student student;

    public EnrollmentScreen(Student s) {

        this.student = s;

    }

    public void ShowScreen() {

        ConsoleUI.clearConsole();
        super.header();
        super.separator();
        this.header();
        this.contentBuilder();

    }

    @Override
    public void header() {
        System.out.println();
        System.out.println("-----------------------------------");
        System.out.println("COURSES OFFERED THIS TERM:");
        System.out.println("-----------------------------------");
    }

    @Override
    public void separator() {

    }

    @Override
    public void closeHeader() {

    }

    @Override
    public void footer() {

    }

    public void contentBuilder() {
    	
    	
        System.out.println();
        System.out.println(" ___________________________________________");
        System.out.println("|" + ConsoleUI.Padding("Index", 6, "center")
                 + "|" + ConsoleUI.Padding("Course ID", 10, "center")
                + "|" + ConsoleUI.Padding("Course Name", 25, "center") + "|");
        System.out.println("|______|__________|_________________________|");
        
        int index = 1;
        for (ArrayList c : courses.getCourseListEnhanced()) {
            System.out.println("|" + ConsoleUI.Padding(String.valueOf(index), 6, "center")
                             + "|" + ConsoleUI.Padding(String.valueOf(c.get(0)), 10, "center")
                             + "|" + ConsoleUI.Padding(String.valueOf(c.get(1)), 25, "center")
                             + "|"
             );
            index++;

        }
        System.out.println("|______|__________|_________________________|");

        System.out.println();
        System.out.println("MESSAGE: The screen displays summary information about courses. Please see the class detail from available classes Screen for more detailed description.");
        System.out.println();
        System.out.println("MESSAGE: To register please select the course you want to register for by selecting options 1-" + (index - 1) + " or press 0 to return.");
        
 
        Scanner input = new Scanner(System.in);
        int choice = -1;

        while (true) {
            System.out.println();
            System.out.print("What is you choice? ");

            /*Input Control Logic*/
            String inputString = input.nextLine();
            boolean isChoiceValid = false;
  		    isChoiceValid  = StudentClassRegistration.inputValidation(inputString,0,index-1); //Allow only integer values equal of less that 5 screens
  		  
	  		  while (!isChoiceValid){
	  			  System.out.print ("Your input is not valid. Please select one of the options from the list? ");
	  			  inputString = input.nextLine();
	    		   isChoiceValid  = StudentClassRegistration.inputValidation(inputString,0,index-1); //Allow only integer values equal of less that 5 screens
 
	  		  }
	  		 
	  		choice = (int)Double.parseDouble(inputString);
            
            
            
            if (choice == 0) {
                break;
            }
            String courseId = String.valueOf(courses.getCourseListEnhanced().get(choice - 1).get(0));
            String studentid = student.GetStudentID();
            //System.out.println(courseId + ", "+studentid);
            
          //Considering the design I must refresh the regrestration object if changes are during the registration
            registrations=null;            
            registrations = new RegistrationHandlerData();
            int messageCode = registrations.EnrollStudentInClass(courseId, studentid);
            if(messageCode ==1){
            	RegistrationStatusScreen regScreen = new RegistrationStatusScreen();
            	 //ConsoleUI.clearConsole();
            	regScreen.ShowScreen();
            	input.nextLine();
            	break;
            }
            System.out.println();
            System.out.println("REGISTRATION MESSAGE: " + registrations.printEnrollmentMessage(messageCode));

        }

        System.out.println("\n\n\ncreate content here\n\n\n");
    }

}

class RegistrationStatusScreen extends ConsoleUI {

	
	
	
	@Override
	public void ShowScreen() {
		    ConsoleUI.clearConsole();
		    this.header();
		    this.separator();
	        this.contentBuilder();
		
	}

	@Override
	public void contentBuilder() {
 		System.out.println("Congratulations. You have successfully Registred for the class");
		
	}

}

class GoodByeScreen extends ConsoleUI {
	Student student = new Student();
    public GoodByeScreen(Student c) {
    	this.student = c;
    }

    public void ShowScreen() {
        ConsoleUI.clearConsole();
        super.header();
        this.separator();
        this.header();      
        this.contentBuilder();
        super.separator();

    }

    @Override
    public void header() {
    	 System.out.println();
         System.out.println("------------------------------------------------------------");
         System.out.println("MESSAGE: Thank you.");
         System.out.println("------------------------------------------------------------");
    }

    @Override
    public void separator() {

    }

    @Override
    public void closeHeader() {

    }

    @Override
    public void footer() {

    }

    public void contentBuilder() {
    	System.out.println(student.GetLastName() + ", " + student.GetFirstName() +" is logged off.");
    	 System.exit(0);
     }

}

class Message extends ConsoleUI {

    @Override
    public void header() {
        System.out.print("\n\n");
        System.out.print("Message Screen:    ");

    }

    @Override
    public void separator() {

    }

    @Override
    public void closeHeader() {

    }

    @Override
    public void footer() {

    }

    public void loginSuccess() {
        //super.header();
        this.header();
        System.out.println("\t\"Login was successul!\"");
        Scanner input = new Scanner(System.in);
        System.out.println("\nPress ANY KEY then ENTER to continue");
        input.nextLine();
    }

    public void loginFailure() {
        //super.header();
        this.header();
        System.out.println("\t\"The combination of user name and password does not match our database\"");
        Scanner input = new Scanner(System.in);
        System.out.println("\nPress ANY KEY and then ENTER to continue");
        input.nextLine();
    }

	@Override
	public void ShowScreen() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void contentBuilder() {
		// TODO Auto-generated method stub
		
	}
}

class WelcomeScreen extends ConsoleUI {

    private Student student;

    public WelcomeScreen(Student s) {

        this.student = s;

    }

    public void ShowScreen() {
        ConsoleUI.clearConsole();
        super.header();
        super.separator();
        this.header();
        this.contentBuilder();

    }

    @Override
    public void header() {
        System.out.println("Welcome to Student Registration!");

    }

    @Override
    public void separator() {

    }

    @Override
    public void closeHeader() {

    }

    @Override
    public void footer() {

    }

    public void contentBuilder() {
        System.out.println();
        System.out.println("--------------------------------------------");
        System.out.println("You are logged in as: " + this.student.GetLastName() + ", " + this.student.GetFirstName());
        System.out.println();
        System.out.println("Please select from one of the options below:");
        System.out.println("--------------------------------------------");
        System.out.println();

        System.out.println("1. View all available classes");
        System.out.println("2. View Student Registration and Profile");
        System.out.println("3. Register for a class");
        System.out.println("4. Unregister from the class");
        System.out.println("5. Exit");

        System.out.println("\n");
        System.out.print("What do you want to do? ");
    }
}

class CourseDetail {

    ArrayList course = new ArrayList();
    CourseHandlerData cHandler = new CourseHandlerData();

    CourseDetail(Course c) {
        for (ArrayList course : cHandler.getCourseListEnhanced()) {
            String courseId = c.GetCourseID();
            if (course.get(0).equals(courseId)) {
                this.course = course;
            }
            ;
        }

    }

    void showCourseDetail() {

        System.out.println(ConsoleUI.Padding("ID", 18, "left") + ": " + this.course.get(0));

        System.out.println(ConsoleUI.Padding("Name", 18, "left") + ": " + this.course.get(1));
        System.out.println(ConsoleUI.Padding("Date", 18, "left") + ": " + this.course.get(2));
        System.out.println(ConsoleUI.Padding("Time", 18, "left") + ": " + this.course.get(3));
        System.out.println(ConsoleUI.Padding("Fee", 18, "left") + ": " + this.course.get(4));
        System.out.println(ConsoleUI.Padding("Description", 18, "left") + ": " + this.course.get(5));
        System.out.println(ConsoleUI.Padding("Days", 18, "left") + ": " + this.course.get(6));
        System.out.println(ConsoleUI.Padding("Instructor", 18, "left") + ": " + this.course.get(7));
        System.out.println(ConsoleUI.Padding("Enrollment", 18, "left") + ": " + this.course.get(9));
        System.out.println(ConsoleUI.Padding("Max Enrollement", 18, "left") + ": " + this.course.get(10));

    }

}
