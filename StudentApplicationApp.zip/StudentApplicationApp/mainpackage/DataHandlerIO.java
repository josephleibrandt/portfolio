package mainpackage;

import java.util.*;


//#########################################################################
//Student Handler Class
//#########################################################################

class StudentHandlerData extends StudentFileData{
	
	 ArrayList<Student> students = new ArrayList<Student>();
	 
	 StudentHandlerData(){
		  StudentFileData studentData = new StudentFileData();
		     
		  int count = super.GetRecordCount();
		  for(int i=0; i < count; i++){
			  Student student = new Student();		
			  studentData.GetStudentRecord(i, student);
			  //System.out.println(student.GetFirstName() + ", " + student.GetLastName() + ", " + student.GetStudentID() + student.GetUserName() 
			  //						+ ", " +  student.GetPassword());
			   this.students.add(student);
			   student = null;

		  }
	 }
	 
	 public ArrayList<Student> getAllStudents(){
		 return this.students;
	 }
	 
	 public void printStudents(){
		 for(Student a: this.students){
			 System.out.println(a.GetFirstName() + ", " + a.GetLastName() + ", " + a.GetStudentID() + ", " + a.GetUserName() + ", " +  a.GetPassword());
		 }
	 }
	 
	 public Student getStudentByUserName(String studentUserName){
		 
		 for(Student s: this.students){
			 if(s.GetUserName().equals(studentUserName)){
				 return s;
			 }
		 }
		 return null;
	 }
	 
	 
	 
	 	 ArrayList<ArrayList> getStudentRegistration(String studentId){
		 ArrayList<ArrayList>  studentRegistrationLong = new ArrayList<>();
		 RegistrationHandlerData registration = new RegistrationHandlerData();
		 
		 ArrayList<ArrayList>  studentRegistration = registration.getStudentRegistration(studentId);
		 
		 CourseHandlerData courses = new CourseHandlerData();
		 
		 for(ArrayList list: studentRegistration){
			// System.out.println(list.get(0));
			 String courseId = (String)list.get(0);
			 
			 for(Course course: courses.getCourseList()){
				 if(courseId.equals(course.GetCourseID())){
					 ArrayList<String> tempReg = new ArrayList<String>();
						tempReg.add(String.valueOf(list.get(2)));
					 	tempReg.add(String.valueOf(list.get(0)));
	 					tempReg.add(course.GetCourseName());	
	 					tempReg.add(course.GetClassDate());	
	 					tempReg.add(course.GetClassFee());
		 				tempReg.add(course.GetClassTime());	
	 					tempReg.add(course.GetCourseDescription());	
	 					tempReg.add(course.GetDays());	
	 					tempReg.add(course.GetInstructorName());
	 					tempReg.add(String.valueOf(registration.getCountOfStudentByClass(course.GetCourseID())));
	 					tempReg.add(registration.getCourseMax(course.GetCourseID()));
	 					studentRegistrationLong.add(tempReg);
				 }
			 }
		 }
		 return studentRegistrationLong;
	 }
	 
}


//#########################################################################
//Course Handler Class
//#########################################################################

class CourseHandlerData extends CourseListFileData{
	private ArrayList<Course> courseList = new ArrayList<Course>();
	
	CourseHandlerData(){
		CourseListFileData courseData = new CourseListFileData();
		
		int count = super.GetCourseCount();
		
		for(int i = 0; i < count; i++){
			Course course = new Course();
			courseData.GetCourse(i, course);
			this.courseList.add(course);
			course = null;
		}
	}
	
	void printAllCourses(){
		RegistrationHandlerData  registration = new RegistrationHandlerData();
		Collections.sort(courseList, new SortCourseList());
		for(Course c: courseList){
			System.out.println("|" + ConsoleUI.Padding(c.GetCourseID(), 15, "center") +
								"|" + ConsoleUI.Padding(c.GetCourseName(), 30, "center") +
								"|" + ConsoleUI.Padding(c.GetClassDate(), 40, "center") +
								"|" + ConsoleUI.Padding(c.GetClassTime(), 20, "center") +
								"|" + ConsoleUI.Padding(c.GetClassFee(), 7, "center") +
								"|" + ConsoleUI.Padding(String.valueOf(registration.getCountOfStudentByClass(c.GetCourseID())), 4, "center") +
								"|" + ConsoleUI.Padding(registration.getCourseMax(c.GetCourseID()), 4, "center") +   
								"|");
								 
				 
		}
	}
	
	ArrayList<ArrayList> getCourseListEnhanced(){
		RegistrationHandlerData  registration = new RegistrationHandlerData();
		ArrayList<ArrayList> store = new ArrayList<ArrayList>();
		Collections.sort(this.courseList, new SortCourseList());
		for(Course course: this.courseList){
			ArrayList<String> temp = new ArrayList<String>();
			 temp.add(course.GetCourseID());
			 temp.add(course.GetCourseName());
			 temp.add(course.GetClassDate());
			 temp.add(course.GetClassTime());
			 temp.add(course.GetClassFee());
			 temp.add(course.GetCourseDescription());
			 temp.add(course.GetDays());	
			 temp.add(course.GetInstructorName());
			 temp.add(course.GetRegistratrionNum());
			 temp.add(String.valueOf(registration.getCountOfStudentByClass(course.GetCourseID())));
			 temp.add(registration.getCourseMax(course.GetCourseID()));
			 
			 store.add(temp);
			 
		}
		
		return store;
	}
	
	ArrayList<Course> getCourseList(){
		Collections.sort(this.courseList, new SortCourseList());
		return this.courseList;
	}
	
	Course getCourse(String courseId){
		 for(Course course:getCourseList()){
		 	   if(course.GetCourseID().equals(courseId)){
		 		   return course;
		 	   }
		  }
		return null;
	}
	
}




//#########################################################################
//Course Handler Class
//#########################################################################

class RegistrationHandlerData extends CourseRegistrationData{
	ArrayList<ClassRegistration> registrations = new ArrayList<ClassRegistration>();
	ArrayList<ArrayList> normalizedRegistration = new ArrayList<ArrayList>();
	
	RegistrationHandlerData() {
		CourseRegistrationData registrationData = new CourseRegistrationData();
	 
		int count = super.GetCourseCount();
		
		for(int i = 0; i < count; i++){
			   ClassRegistration registration = new ClassRegistration();
			   registrationData.GetCourseEnrollment(i, registration);
			   //System.out.println(registration.GetCourseID() + " " + registration  );
			   this.registrations.add(registration);
			   registration = null;
		   }
		
		for(ClassRegistration r: this.registrations){
			
			
			for(String studentId : r.GetCourseEnrollment()){
				ArrayList<String> tempList = new ArrayList<String>();

				 tempList.add(r.GetCourseID());
				 tempList.add(r.GetEnrollmentMax());
				 tempList.add(studentId);
				 //System.out.println(tempList);
				 
				 this.normalizedRegistration.add(tempList);
			}
			
		}
	}
	
 
	void printAllRegistrations(){
		for(ArrayList list: this.normalizedRegistration){
			 
			System.out.println(list);
		}
	}
	
	ArrayList<ArrayList> getStudentRegistration(String studentId){
		ArrayList<ArrayList> studentRegistration = new ArrayList<ArrayList>();
		for(ArrayList list: this.normalizedRegistration){
			if(list.get(2).equals(studentId)){
				studentRegistration.add(list);
			}
		}
		
		return studentRegistration;
	}
	
	ArrayList<ArrayList> getClassRegistration(String classId){
		ArrayList<ArrayList> classRegistration = new ArrayList<ArrayList>();
		for(ArrayList list: this.normalizedRegistration){
			if(list.get(0).equals(classId)){
				classRegistration.add(list);
			}
		}
		
		return classRegistration;
	}
	
	
	void printStudentRegistrations(String studentId){
		ArrayList<ArrayList> reg = getStudentRegistration(studentId);
		for(ArrayList list: reg){
			System.out.println(list);
		}
	}
	
	 
	
	int getCountOfStudentByClass(String classId){
		
		int count=0;
		for(ArrayList r: this.normalizedRegistration){
			if(r.get(0).equals(classId)){
				count++;
			}
		}		
		return count;
	}
	
	String getCourseMax(String courseId){
		for(ClassRegistration list: this.registrations){
			if(list.GetCourseID().equals(courseId)){
				return list.GetEnrollmentMax();
			}
			//System.out.println(list.GetEnrollmentMax());
		}
		
		return null;
	}
	
	boolean isClassFull(String courseId){
		
		if(!doesClassExist(courseId)){
			return false;
		}
		int maxEnrollment = Integer.parseInt(getCourseMax(courseId));
		int currentEnrollment = this.getCountOfStudentByClass(courseId);
		
		return currentEnrollment>=maxEnrollment? true:false;
	}
	
	boolean isStudentRegistered(String courseId, String studentId){
		 ArrayList<ArrayList> list = this.getClassRegistration(courseId);
		
		 for(ArrayList registration: list){
		    	if(registration.get(2).equals(studentId)){
		    		return true;
		    	}
		    }
		return false;
	}
	
	boolean doesClassExist(String courseId){
		CourseHandlerData courses = new CourseHandlerData();
		for(ArrayList course: courses.getCourseListEnhanced()){
		 	   if(course.get(0).equals(courseId)){
		 		   return true;
		 	   }
		  }
 
		return false;
	}
	
	boolean doesStudentExist(String studentId){
		StudentHandlerData studentData = new StudentHandlerData();
		 for(Student s: studentData.getAllStudents()){
			 if(s.GetStudentID().equals(studentId)) {
				 return true;
			 }
			 
			   
		   }
		return false;
	}
	 
	 int EnrollStudentInClass (String courseId, String studentId){
		 
		int messageCode = 0;
		boolean doesStudentExist = this.doesStudentExist(studentId);
		boolean doesClassExist = this.doesClassExist(courseId);
		boolean isStudentRegistered = isStudentRegistered(courseId, studentId);
		boolean isClassFull = this.isClassFull(courseId);
		
		if(doesClassExist && !isStudentRegistered && !isClassFull && doesStudentExist){
			ArrayList<String> newReg= new ArrayList<>();
			newReg.add(courseId);
			newReg.add(this.getCourseMax(courseId));
			newReg.add(studentId);			
			this.normalizedRegistration.add(newReg);
			
			CourseRegistrationData registrationData = new CourseRegistrationData();
			registrationData.GetCourseEnrollment(courseId, new ClassRegistration());
			registrationData.EnrollStudenttoClass(courseId,studentId);
			
			return messageCode = 1;
			
		} else if (!doesClassExist && doesStudentExist){
			
			return messageCode = 2;
			
		}else if (isStudentRegistered && doesStudentExist){
			
			return messageCode = 3;
			
		}else if (isClassFull && doesStudentExist){
			
			return messageCode = 4;
			
		}else if (!doesStudentExist){
			
			return messageCode = 8;
			
		} 
			
		return messageCode;
		 
		
		
	}
	
	
	
	
	 
	int UnEnrollStudentInClass (String courseId, String studentId){
		
		int messageCode = 0;
		boolean doesStudentExist = this.doesStudentExist(studentId);
		boolean doesClassExist = this.doesClassExist(courseId);
		boolean isStudentRegistered = this.isStudentRegistered(courseId, studentId);
	
		
		if(doesClassExist && isStudentRegistered && doesStudentExist){
			ArrayList<String> newReg= new ArrayList<>();
			
			newReg.add(courseId);
			newReg.add(this.getCourseMax(courseId));
			newReg.add(studentId);
			int index = 0;
 			for(ArrayList list: this.normalizedRegistration){
				
				//System.out.println(list.get(0).equals(courseId) + " " + list.get(2).equals(studentId));

				if(list.get(0).equals(courseId) && list.get(2).equals(studentId)){
					
					//System.out.println(list.get(0).equals(courseId) + " " + list.get(2).equals(studentId));
					//System.out.println(index);
 					this.normalizedRegistration.remove(index);
					break;
				}
				index++;
			}
		 
  			
			CourseRegistrationData registrationData = new CourseRegistrationData();
			registrationData.GetCourseEnrollment(courseId, new ClassRegistration());
			registrationData.UnEnrollStudenttoClass(courseId,studentId);;
			
			return messageCode = 5;
			
		} else if (!isStudentRegistered && doesStudentExist){
			
			return messageCode = 6;
			
		}else if (!doesClassExist && doesStudentExist){
			
			return messageCode = 7;
			
		}else if (!doesStudentExist){
			
			return messageCode = 8;
			
		} 		
		
		return messageCode;
	}
	
	
	
	public String printEnrollmentMessage(int messageCode){
		String message;
		if (messageCode==0)
			message = "ERROR: Unknown Error.";
		else if( messageCode==1)
			message = "SUCCESS: Succesful registration!";
		else if( messageCode==2)
			message = "ERROR: Class you are trying to register does not exist.";
		else if( messageCode==3)
			message = "ERROR: You are already registered for this class.";
		else if( messageCode==4)
			message = "ERROR: Class is full";
		else if( messageCode==5)
			message = "SUCCESS: Succesful un-enrollment!";
		else if( messageCode==6)
			message = "ERROR: You canot unregister for the class that you are not registered for.";
		else if( messageCode==7)
			message = "ERROR: Class you are trying to unregister for does not exist.";
		else if( messageCode==8)
			message = "ERROR: Student with this ID does not exist.";
		else 
			message = "Uknown registration issue";
		return message;
	}
	 
}




 //#########################################################################
//Comparator for sorting course List
//#########################################################################

 
class SortCourseList implements Comparator<Course>{

	@Override
	public int compare(Course c0, Course c1) {
		// TODO Auto-generated method stub
		
		return c0.GetCourseName().compareToIgnoreCase(c1.GetCourseName());
	}
	
}