package mainpackage;

import interfacepackage.*; 
import java.util.*;


public class StudentClassRegistration 
{
   public static void main(String args[]) throws Exception 
   {
	   
	   
		  // screen constants	   
	    final int COURSE_LIST = 0;
	    final int REG_STATUS = 1;
	    final int STUDENT_PROFILE = 2;
	    final int MAIN_OPTIONS = 3;
	    final int AVAILABLE_COURSE_SCREEN = 4;
	    final int UNENROLLMENT_SCREEN = 5;
	    final int ENROLLMENT_SCREEN = 6;

	  
	  // Instatiate screen objects

	    
		   StudentHandlerData studentData = new StudentHandlerData();		 
		   CourseHandlerData courses = new CourseHandlerData(); 		   
		   RegistrationHandlerData registrations = new RegistrationHandlerData(); 
		 	  
		   
		   
		   Message message  = new Message();
		   LogInScreen login  = new LogInScreen();
		    
		  
		   String userName ="";
		   String passWord ="";
		   boolean loginSuccess = false;
		   
		   while(!loginSuccess){
		   
			   login.ShowScreen();
			 
			   userName = login.getUserName();
			   passWord = login.getPassword();
			   
			   PasswordControl val = new PasswordControl();
			   
 			   
			   boolean succesfulValidaiton = val.ValidateAccess(userName, passWord);
			   
			   if(!succesfulValidaiton){
				   message.loginFailure();
			   }else{
				   
				   message.loginSuccess();
				   loginSuccess = true;
			   }
				  
			  }
	  		
		 
		 
		
		   /*get student by providing username*/
		    
		    Student student = studentData.getStudentByUserName(userName);
		   
		   
 			  ConsoleUI[] screen = new ConsoleUI[7];
			  screen[COURSE_LIST] = new StudentProfileScreen(student);
			  //screen[REG_STATUS] = new RegistrationStatusScreen();
			  screen[STUDENT_PROFILE] = new GoodByeScreen(student);
			  screen[AVAILABLE_COURSE_SCREEN] = new AvailableCourseScreen();
			  screen[UNENROLLMENT_SCREEN] = new UnEnrollmentScreen(student);
			  screen[ENROLLMENT_SCREEN] = new  EnrollmentScreen(student);
			  screen[MAIN_OPTIONS] = new WelcomeScreen(student);

 		 
		   //##################################################################################################################
		   
	    
	  
	  while(true)
	  {		
		  
		  ((WelcomeScreen)screen[MAIN_OPTIONS]).ShowScreen();
		  Scanner input = new Scanner(System.in);
		  boolean isChoiceValid = false;
  
		  String inputString = input.nextLine();
		   isChoiceValid  = inputValidation(inputString, 1, 5); //Allow only integer values equal of less that 5 screens
		  
		  while (!isChoiceValid){
			  System.out.print ("Your input is not valid. Please select one of the options from the list? ");
			  inputString = input.nextLine();
			   isChoiceValid  = inputValidation(inputString, 1, 5); //Allow only integer values equal of less that 5 screens
			  
		  }
		 
		  
		  int choice = (int)Double.parseDouble(inputString);
 	  
		  if  (choice == 1)
		  {
			  ((AvailableCourseScreen)screen[AVAILABLE_COURSE_SCREEN]).ShowScreen();
			  
		  } 
		  else if (choice  == 2)
		  {
			  ((StudentProfileScreen)screen[COURSE_LIST]).ShowScreen();
		  }
		  else if (choice == 3)
		  {
			  ((EnrollmentScreen)screen[ENROLLMENT_SCREEN]).ShowScreen();

		  }else if (choice == 4)
		  {
			  ((UnEnrollmentScreen)screen[UNENROLLMENT_SCREEN]).ShowScreen();

		  }		  
		  else if (choice == 5)
		  {
			  input.close();
			  ((GoodByeScreen)screen[STUDENT_PROFILE]).ShowScreen();

		  }
		   
	  }   
	    
   }
   
   public static boolean inputValidation(String choice, int lowChoice,  int upperChoice) {
       //is input a number
       boolean validChoide = false;
       if (isNumeric(choice)) {             
             double choiceDouble =   Double.parseDouble(choice);
             
           if (choiceDouble == (int) choiceDouble) {
               
               if ((int) choiceDouble <= (int) upperChoice && (int) lowChoice <=(int) choiceDouble ) {
                     return true;
                   //return validChoide;
               }              
           }         
       }
       return false;

   }

   public static boolean isNumeric(String str) {
       try {
           double d = Double.parseDouble(str);
       } catch (NumberFormatException nfe) {
           return false;
       }
       return true;
   }
}

// This class will serve to manage the registration rules for the app
class RegistrationRules
{
   RegistrationRules()
   {
	   
   }
   
   
}

// This class will serve to process the user Id and password access
class PasswordControl implements PasswordControlInterface
{
   PasswordControl()
   {
	   
   }
      
   public boolean ValidateAccess(int studentid, String enteredusername, String enteredpassword )
   {
	  return true;   
   }
   
   public  boolean ValidateAccess(String enteredusername, String enteredpassword)
   {
	   StudentHandlerData studentData = new StudentHandlerData();
	   
	   for(Student s: studentData.getAllStudents()){
 		   if(s.GetUserName().equals(enteredusername)){
 			   if(s.GetPassword().equals(enteredpassword)){
 				  return true;	
			   }			   	   

		   }	  
		   
	   }
	  return false;   
   }

}