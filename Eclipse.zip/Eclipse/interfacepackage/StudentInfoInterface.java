package interfacepackage;

import mainpackage.*;

public interface StudentInfoInterface {
	/*
	 * here we define the methods that we want to be implemented in student info class
	 * Without these methods the user of the student info class will not know how is 
	 * student info implement (unless he looks). e.g. how to call list of student, how to add student,
	 * how to remove student etc. Agreeing in advance how this is done facility 
	 * the development. 
	 */
	
	 void addStudent(java.util.ArrayList<Student> sList, Student s);
	 void addNewStudent(Student s);
	 void deleteStudent(Student s);
	 java.util.ArrayList<Student> getAllStudents();
	 /*define other methods that must be implemented in Student Info*/
}
