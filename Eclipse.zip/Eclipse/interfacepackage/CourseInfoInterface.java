package interfacepackage;

import mainpackage.Course;

public interface CourseInfoInterface {
	/*
	 * here we define the methods that we want to be implemented in course info class
	 * Without these methods the user of the course info class will not know how is 
	 * student info implement (unless he looks). e.g. how to call list of classes, how to add class,
	 * how to remove class etc. Agreeing in advance how this is done facility 
	 * the development. 
	 */
	
	 void addCourse(Course c);
     void deleteCourse(Course c);
     void printAllCourseInAlphabeticOrder();
     /*define other methods that must be implemented in Course Info*/
}
