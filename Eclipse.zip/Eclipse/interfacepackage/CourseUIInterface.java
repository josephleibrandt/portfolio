package interfacepackage;

public interface CourseUIInterface {

}
