package interfacepackage;

public interface StudentRegistrationInterface {

}
