package mainpackage;

import interfacepackage.*;

public class Course 
{
	String courseName;
	String courseInstruction;
	int courseId;
	
	Course(){
		
	}
	
	Course(String courseName,String courseInstructor, int courseId){
		
	}

}
