package mainpackage;

import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;

import interfacepackage.CourseUIInterface;

import java.util.Scanner;


public class ConsoleUI implements CourseUIInterface
{
   public ConsoleUI(){}
}


class Screen1 extends ConsoleUI
{
	public Screen1(){}
	
	public void Display()
	{
	   System.out.println("Screen1: "); 
	}
}


class Screen2 extends ConsoleUI
{
	public Screen2(){}
	
	public void Display()
	{
	   System.out.println("Screen2: "); 
	}
}


class Screen3 extends ConsoleUI
{
	public Screen3(){}
	
	public void Display()
	{
	   System.out.println("Screen3: "); 
	}
}
