package mainpackage;

import interfacepackage.*;

public class Student  
{
	private String firstName;
	private String lastName;
	private String userName;
	private String password;
	private int studentId;
	
	Student(){
		
	};
	
	Student(String  firstName, String lastName, String username, String password, int id){
		
	};
}
