package mainpackage;


import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;
import java.util.Scanner;
import interfacepackage.*; 

public class DataFileIO 
{
	DataFileIO(){}
}

class CourseInfo extends DataFileIO implements CourseInfoInterface
{
	ArrayList<Student> studentlist = new ArrayList<Student>();

	CourseInfo(){}	
}

class StudentInfo extends DataFileIO implements StudentInfoInterface
{
	ArrayList<Course> courseList = new ArrayList<Course>();

	StudentInfo(){}	
}


