package interfacepackage;
import mainpackage.*;

public interface PasswordControlInterface 
{
   public boolean ValidateAccess(int studentid, String enteredusername, String enteredpassword );
}
